# Job Hunt Stack
### Your AI-Powered Job Hunting Workspace

---

## Quick Start

**Option A (Recommended):** Give `CONTEXT_SEED.md` to your AI assistant and say "Please read this and guide me through setting up my Job Hunt Stack."

**Option B:** Read `Cold Start Primer.md` and follow the startup checklist manually.

---

## Folder Map

```
Job Hunt Stack/
├── README.md                  ← You are here
├── Cold Start Primer.md       ← Read this at the start of EVERY session
├── Archive Protocol.md        ← Session close checklist
├── Master Lessons Learned.md  ← Your growing knowledge base
├── CONTEXT_SEED.md            ← Give this to the AI for guided setup
├── Identity/
│   └── [User] Profile.md     ← YOUR professional source of truth
├── Rules/
│   └── Global Instructions.md ← Hard rules the AI follows
├── Agents/
│   ├── TSA J Search.md        ← Job board search agent
│   ├── TSA J Leads.md         ← Lead triage and pipeline agent
│   ├── TSA Port.md            ← Portfolio and application writing agent
│   └── TSA Flo.md             ← Workflow coordinator and scheduler
├── 02_LIVE_TRACKER/
│   └── Job Hunt Template.xlsx ← Master tracker spreadsheet
├── 03_COVER_LETTERS/          ← Cover letter output
├── 04_JOB_LEADS/              ← LeadCard files
├── 05_OUTPUTS/                ← Tailored resumes and deliverables
├── 06_ARCHIVE/                ← Session records
├── DUPE/                      ← Duplicate file staging
└── delete.me/                 ← Retired file staging
```

---

## Session Startup Protocol

Every session, in order:

1. Read `Cold Start Primer.md`
2. Check `Master Lessons Learned.md` for prior insights
3. Load the relevant agent from `Agents/`
4. State your plan, get approval, execute
5. At session end: run `Archive Protocol.md`

---

## The Four Agents

| Agent | When to Load |
|-------|-------------|
| **TSA J Search** | Searching for new job leads |
| **TSA J Leads** | Evaluating leads, managing the pipeline, updating the tracker |
| **TSA Port** | Writing cover letters, tailoring resumes, building your portfolio |
| **TSA Flo** | Planning your schedule, coordinating across agents, tracking progress |

---

## Output Rules

- Cover letters: `.docx` + `.pdf`, saved to `03_COVER_LETTERS/`
- LeadCards: `.md`, saved to `04_JOB_LEADS/`
- Tailored resumes: `.docx` + `.pdf`, saved to `05_OUTPUTS/`
- Session summaries: `.md`, saved to `06_ARCHIVE/`

---

*Job Hunt Stack v2.0 | Created by James Kelly, PMP - Flo Masta Jay Consultings LLC*
*Part of the W2W Philanthropic Project*
