# Archive Protocol
### Job Hunt Stack - Session & Artifact Archiving Standard
*Version 2.0 | Public Release*

---

> **Trigger phrase:** When you say **"I'm ready to archive this chat"** (or similar), this protocol activates.

---

## Part 1 - Artifact Archiving

### When to Archive a File

- A file has been superseded by a newer version (e.g., updated resume replaced the old one)
- A document was created for a one-time task that is now complete
- A LeadCard for a position that's been filled or expired

### How to Archive

1. Move the file to `06_ARCHIVE/`
2. Rename with date prefix: `YYYY-MM-DD [OriginalFilename].[ext]`
3. Note the action in the session summary

---

## Part 2 - Session Close Checklist

### Step 1 - Session Summary

Compile a brief summary covering:
- Date of session
- Primary tasks completed
- Files created, modified, or deleted
- Pipeline changes (new leads, status updates, applications submitted)

### Step 2 - Lessons Learned Check

Review the session for additions to `Master Lessons Learned.md`:
- Did anything unexpected happen?
- Did you discover something useful (a good job board, a cover letter approach that worked)?
- Did a rule get clarified or refined?
- Did something fail that should be documented so it isn't repeated?

If yes: add to Master Lessons Learned before closing. Number sequentially.

### Step 3 - Cold Start Primer Update

Update Section 3 (Current Workspace Status) in `Cold Start Primer.md`:
- Bump the session number
- Note what changed
- Set the "Next step" for the following session
- List any carry-over tasks

### Step 4 - Save Session Record

Save the session summary to `06_ARCHIVE/`:
- Filename: `YYYY-MM-DD Session Summary [brief descriptor].md`

### Step 5 - Output Compliance Check

Verify all session outputs against the active agent's Output Compliance Checklist. If something was missed, fix it before closing.

### Step 6 - Next Session Launch Prompt

Output this block, ready to copy:

---
**Copy this into your next session to initialize:**

```
Please read the Cold Start Primer at the root of the Job Hunt Stack folder, then load [agent name] from Agents/[agent file].
```
---

---

## Part 3 - DUPE Protocol

Over time, duplicate files appear (auto-saved copies, version conflicts, export artifacts). Handle them:

| Signal | Action |
|--------|--------|
| File with `(1)` or `copy` suffix | Move to `DUPE/`; confirm original is in the correct location |
| Older version alongside newer | Move older to `DUPE/`; keep newer in place |
| Temporary files (.tmp) | Move to `delete.me/` |

**Never permanently delete anything without reviewing it first.** The two-stage system (DUPE/ and delete.me/) gives you a safety buffer.

- **DUPE/**: Duplicates and superseded versions. Review periodically, delete when confident.
- **delete.me/**: Retired files you're confident about removing. Review and permanently delete when ready.

Both folders should contain a README explaining their current contents.

---

## Part 4 - Unfinished Task Note

If any task was attempted but not completed during this session (due to time, tool issues, or mid-session pivots), save a note:

- Filename: `[TaskName] Unfinished Task Note YYYY-MM-DD.md`
- Location: `06_ARCHIVE/`
- Include: what was attempted, why it stopped, what the next session should do

This prevents work from silently disappearing between sessions.

---

*Archive Protocol v2.0 | Public Release | Job Hunt Stack*
*"Close it clean. Carry it forward. Nothing gets lost."*
