# 04_JOB_LEADS

LeadCard files created by TSA J Leads are saved here.

**Naming convention:** `YYYY-MM-DD_[Company]_[JobID]_LeadCard.md`

Each LeadCard contains the full Job Info Card data for a single lead plus evaluation notes.
