# Job Hunt Stack - Context Seed
### Give This File to Your AI Assistant to Set Up Your Workspace

---

## Instructions for the AI

You are helping a user set up the **TSA Job Hunt Stack v2.0**, an AI-powered job hunting workflow system. This file contains everything you need to guide them through setup. Read it completely before taking any action.

### What This System Is

The Job Hunt Stack is a structured workspace with four specialized AI agents, a session lifecycle that prevents chat amnesia, and a 7-step workflow from first job search to offer accepted. The user has downloaded a zip file containing the complete workspace.

### Your Setup Tasks (in order)

**Task 1: Verify the folder structure**

Confirm the user has unzipped the download and the following structure exists:

```
Job Hunt Stack/
├── README.md
├── Cold Start Primer.md
├── Archive Protocol.md
├── Master Lessons Learned.md
├── CONTEXT_SEED.md (this file)
├── Identity/
│   └── [User] Profile.md
├── Rules/
│   └── Global Instructions.md
├── Agents/
│   ├── TSA J Search.md
│   ├── TSA J Leads.md
│   ├── TSA Port.md
│   └── TSA Flo.md
├── 02_LIVE_TRACKER/
│   └── Job Hunt Template.xlsx
├── 03_COVER_LETTERS/
├── 04_JOB_LEADS/
├── 05_OUTPUTS/
├── 06_ARCHIVE/
├── DUPE/
│   └── README.md
└── delete.me/
    └── README.md
```

If any files or folders are missing, help the user create them.

**Task 2: Fill in the User Profile**

Open `Identity/[User] Profile.md` and walk the user through completing every section. This is the most important setup step. Ask them about:

1. Full name, professional title, certifications
2. Location and contact info
3. Work history (reverse chronological, with quantified achievements per role)
4. Education
5. Skills inventory (technical, soft skills, tools, methodologies)
6. Values statement (what they care about in a workplace)
7. Language proficiency (if multilingual)

Help them write strong, quantified achievement bullets for each role. Guide them toward specific numbers: "How many people did you manage?" "What percentage did efficiency improve?" "How much revenue/cost was involved?"

**Task 3: Configure Global Instructions**

Open `Rules/Global Instructions.md` and help the user customize:

- File naming preferences (do they want a specific format?)
- Language rules (if multilingual, which language shows first?)
- Currency display preferences
- Any personal formatting preferences
- Their values framework (this replaces the placeholder section)

**Task 4: Customize the Cold Start Primer**

Open `Cold Start Primer.md` and update:

- Section 1: User's name and relevant context
- Section 3: Set to "Session 0: Initial setup complete" with today's date
- Verify all file paths match the actual folder structure

**Task 5: Review the Agents**

Briefly walk the user through each agent's purpose:

- **TSA J Search**: "This agent searches for jobs. When you're ready to search, you'll load this file."
- **TSA J Leads**: "This agent manages your pipeline. It tracks every lead from discovery to outcome."
- **TSA Port**: "This agent writes your cover letters, tailors your resume, and builds your portfolio."
- **TSA Flo**: "This agent coordinates everything. It helps you plan your time and stay on track."

Ask if they want to customize the evaluation rubric weights in TSA J Leads (default: Values 40%, Remote+Salary 30%, Role 20%, Location 10%).

**Task 6: Set up the Tracker**

Open `02_LIVE_TRACKER/Job Hunt Template.xlsx` and walk the user through:

- The Job Leads tab (where applications are tracked)
- The Job Search Websites tab (where to search)
- Any other tabs present in the template
- How to add their preferred job boards to the Websites tab

**Task 7: Choose a Mode**

Ask the user:

"You have two ways to use this system:

**Mode A: Run It Like Flo** - Use everything exactly as shipped. Just fill in your profile and start hunting. The agents, rules, and workflows are battle-tested.

**Mode B: Make It Yours** - Keep the structural framework but customize the agents, evaluation criteria, folder names, and workflow to match your own approach.

Which do you prefer? (You can always switch later.)"

If Mode B: help them identify what they want to customize and make the changes.

**Task 8: First Session Dry Run**

Walk the user through a mock session:

1. "Pretend you're starting a new chat tomorrow. You'd load Global Instructions, then Cold Start Primer, then an agent."
2. Show them how the Cold Start Primer references their profile and the current status
3. Explain that at the end of every session, they'll run the Archive Protocol to capture what happened
4. Explain that Master Lessons Learned grows over time and makes every session smarter

**Task 9: Confirm Setup Complete**

Update the Cold Start Primer Section 3:
```
Last updated: [today's date] (Session 0, setup complete)
Setup mode: [Mode A or Mode B]
Next step: Load TSA J Search and begin Step 1 of the Workflow (sourcing leads)
```

Tell the user: "You're set up. Next time you start a new chat, give the AI your Cold Start Primer and you'll be right back where you left off."

---

## System Overview (for AI reference)

### The Five Pillars

| Pillar | File | Purpose |
|--------|------|---------|
| Rules | `Rules/Global Instructions.md` | Hard rules, always active |
| Primer | `Cold Start Primer.md` | Session boot sequence, carries state between sessions |
| Identity | `Identity/[User] Profile.md` | User's professional source of truth |
| Lessons | `Master Lessons Learned.md` | Living log of insights from every session |
| Archive | `Archive Protocol.md` | Session close checklist |

### The Four Agents

| Agent | File | Domain |
|-------|------|--------|
| TSA J Search | `Agents/TSA J Search.md` | Job board search, lead discovery |
| TSA J Leads | `Agents/TSA J Leads.md` | Lead triage, pipeline management |
| TSA Port | `Agents/TSA Port.md` | Cover letters, resume, portfolio |
| TSA Flo | `Agents/TSA Flo.md` | Scheduling, coordination, flow |

### The 7-Step Workflow

1. Source leads via Teal/Simplify/job boards
2. Build resume using ATS keywords from job descriptions
3. Create Master ATS List from resume template
4. Refine custom resumes and cover letters per lead
5. Color-scan all leads against personal preferences
6. Mass apply for relevant leads
7. Expand to LinkedIn, specialty boards, networking

### Session Lifecycle

```
Global Instructions → Cold Start Primer → Load Agent → Work → Lessons Learned → Archive Protocol → Next Session
```

---

## For the User

If you're reading this directly: you don't need to understand everything above. Just give this entire file to your AI assistant (paste it or upload it) and say:

**"Please read this and guide me through setting up my Job Hunt Stack."**

The AI will handle the rest.

---

*TSA Job Hunt Stack v2.0 | Context Seed*
*Created by James Kelly, PMP - Flo Masta Jay Consultings LLC*
*Part of the W2W Philanthropic Project*
