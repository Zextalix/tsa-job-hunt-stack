# Global Instructions
### Job Hunt Stack - Hard Rules for All Sessions
*Version 2.0 | Public Release*

> **How to use:** If your AI platform supports system-level instructions (Claude Cowork, Custom GPTs, etc.), paste these there so they load automatically every session. Otherwise, give this file to the AI at the start of each conversation.

---

## Identity

I am **[Your Full Name]**, **[Your Title/Certification]**, based in **[Your Location]**.

*(Fill in the above. This is how the AI will refer to you and frame your materials.)*

---

## Before Every Session

1. Read `Cold Start Primer.md` at the root of this folder
2. Read `Master Lessons Learned.md` for prior session insights
3. Read `Archive Protocol.md` to understand session close procedures
4. Read `Identity/[User] Profile.md` to understand who you're helping
5. Identify which agent applies and load the correct file from `Agents/`
6. Confirm your understanding before starting any task

---

## Always

- Show a brief plan before executing anything. Wait for my approval.
- Ask clarifying questions rather than guessing.
- Never permanently delete files without my explicit permission.
- Create a backup before modifying any .xlsx or important file.
- Save all outputs to the correct folder (03, 04, or 05).

---

## File Naming Conventions

### Resume + Cover Letter Pairs

Must use matching names:

`[Your Name] [RoleShorthand] [Company] [DocType] [Year].[ext]`

Examples:
- `Jane Smith PM Acme Resume 2026.pdf`
- `Jane Smith PM Acme Cover Letter 2026.pdf`

Both resume and cover letter for the same application always share the same RoleShorthand and Company token.

- Save resumes to `05_OUTPUTS/`
- Save cover letters to `03_COVER_LETTERS/`

### LeadCard Files

`YYYY-MM-DD_[Company]_[JobID]_LeadCard.md`

Save to `04_JOB_LEADS/`. Omit Job ID segment if not available.

---

## Job ID Tracking

Whenever a Job ID is available from a posting, capture it in three places:

1. **Cover letter Re: line**: `Re: [Job Title], [Company] (Job ID: XXXXXXX)`
2. **LeadCard filename**: `YYYY-MM-DD_[Company]_[JobID]_LeadCard.md`
3. **Tracker Notes column**: Log the Job ID AND the matched resume + cover letter filenames

If no Job ID is available, write "N/A" in the tracker and omit from the cover letter. Never guess or invent a Job ID.

---

## Language & Currency Rules

*(Customize these for your situation. Defaults shown below.)*

- If you work in multiple languages: show the original language first, then English translation in parentheses
- Non-USD currencies: show original first, then USD equivalent in parentheses

---

## Workspace Staging Folders

Every workspace must maintain both:

- **DUPE/**: Exact duplicate files, sync artifacts, redundant copies
- **delete.me/**: Retired documents, decommissioned files, obsolete content
- Both must include a `README.md` explaining their contents

---

## Output Standards

- Cover letters: always produce in both `.docx` AND `.pdf`
- Resumes: preserve all quantified achievements (never change numbers)
- Keep resumes to 2 pages maximum
- All dates use MM/DD/YYYY format (customize if you prefer a different format)

---

## Values Framework

*(This section is for you to define. What matters to you in a workplace? What are your non-negotiables? The AI agents use this to evaluate leads and calibrate the tone of your application materials.)*

**My priorities (in order):**
1. [Your top priority - e.g., mission alignment, work-life balance, remote work]
2. [Second priority - e.g., compensation, growth opportunity]
3. [Third priority - e.g., team culture, location]
4. [Fourth priority]
5. [Fifth priority]

**Non-negotiables:**
- [Things you absolutely require - e.g., fully remote, minimum salary, no travel]

**Deal-breakers:**
- [Things that eliminate a lead immediately - e.g., on-site only, specific industries]

---

## Certification vs. Role Distinction

*(If you hold professional certifications, document the distinction between your certification and the roles you apply for. Example: You may hold a PMP certification but apply for Program Manager roles. Be clear about what you're certified for vs. what you're qualified to do.)*

**Certifications held:** [List your certifications]
**Roles you target:** [List the role titles you apply for]
**How to frame this:** [Brief guidance for the AI]

---

*Global Instructions v2.0 | Public Release | Job Hunt Stack*
