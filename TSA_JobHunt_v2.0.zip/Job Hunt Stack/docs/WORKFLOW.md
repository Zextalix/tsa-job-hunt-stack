# Job Hunt Stack: 7-Step Workflow Guide
### From First Search to Offer Accepted

---

## Overview

This workflow takes you from zero to employed. Each step builds on the previous one. Don't skip ahead. The discipline of following the sequence is what makes the system work.

```
Step 1: Source → Step 2: Build → Step 3: Template → Step 4: Refine → Step 5: Scan → Step 6: Apply → Step 7: Expand
```

---

## Step 1: Source Leads via Teal / Simplify Jobs

**Agent**: TSA J Search
**Goal**: Build your initial pool of job leads

Start by using job aggregator platforms to cast a wide net:

- **Teal** (tealhq.com): AI-powered job tracking and resume matching
- **Simplify Jobs** (simplify.jobs): One-click batch applications with saved profiles
- **LinkedIn Jobs**: Filter by remote, salary, experience level
- **Indeed / Glassdoor**: Broad coverage with company reviews

### What to do:

1. Set up profiles on Teal and/or Simplify
2. Configure your search filters (role, location, remote, salary range)
3. Save promising leads. Don't apply yet.
4. Feed the leads to TSA J Search for deeper evaluation
5. TSA J Search produces a ranked Top 10 list with Job Info Cards

### Key principle:

At this stage, quantity matters more than precision. You're building a pool to filter from, not committing to applications. Save 20-30 leads before moving to Step 2.

---

## Step 2: Create / Refine Your Resume by Searching Jobs

**Agent**: TSA Port (with TSA J Search support)
**Goal**: Build an ATS-optimized master resume

Now that you have a pool of leads, use them to inform your resume:

1. Read through 10-15 job descriptions in your target role
2. Extract the most common keywords, skills, and qualifications they mention
3. Cross-reference against your actual experience
4. Work with TSA Port to build (or refine) your resume so it hits the most common ATS keywords

### What you're building:

A **master resume** that is broadly optimized for your target role category. This is not tailored to any single job yet. It's a strong baseline that matches the language your industry uses.

### Key principle:

Your resume should pass ATS screening for 70%+ of the roles in your target category without any customization. That's the benchmark for a good master resume.

---

## Step 3: Download Resume as Template for Master ATS List

**Agent**: TSA J Leads (with TSA Port support)
**Goal**: Create your Master ATS Keyword List

Your master resume is now your template. Extract from it:

1. **Every ATS keyword** you've included (skills, tools, certifications, methodologies)
2. **Keywords you're missing** that appeared frequently in job descriptions
3. **Keywords you could add** if you slightly reframe existing experience

Compile these into a **Master ATS List**: a single reference document that maps your skills to the language job postings use. This list lives alongside your tracker and grows over time.

### Format suggestion:

| Your Skill / Experience | ATS Keyword(s) | Frequency in JDs | In Master Resume? |
|------------------------|----------------|-------------------|-------------------|
| Led cross-functional teams | Cross-functional leadership, team management | High | Yes |
| Used Jira for sprint planning | Jira, Agile, sprint planning, Scrum | High | Yes |
| Managed project budgets | Budget management, cost control, P&L | Medium | No - add |

### Key principle:

The Master ATS List becomes your cheat sheet for every future resume customization. Instead of re-analyzing each job description from scratch, you can quickly map its requirements against your list.

---

## Step 4: Refine Custom Resumes and Cover Letters from Master ATS List

**Agent**: TSA Port (triggered by TSA J Leads Top 3 selection)
**Goal**: Produce tailored application packages for priority leads

Now you apply precision:

1. TSA J Leads selects the **Top 3 priority leads** from the pipeline
2. For each lead, TSA Port creates:
   - A **tailored resume** (reorder bullets, add/emphasize matching keywords from the Master ATS List)
   - A **tailored cover letter** (tone-matched to the company, with specific achievements)
3. Both documents follow the matched pair naming convention:
   - `[Your Name] [RoleShorthand] [Company] Resume [Year].pdf`
   - `[Your Name] [RoleShorthand] [Company] Cover Letter [Year].pdf`
4. TSA J Leads logs the filenames in the tracker Notes column for traceability

### As you customize, update the Master ATS List:

- Found a new keyword that appears in multiple postings? Add it to the list.
- Realized a skill on your list doesn't match how companies phrase it? Update the mapping.

### Key principle:

The Master ATS List is a living document. Every application you prepare makes it more accurate, which makes future applications faster.

---

## Step 5: Scan All Leads for Personal Preferences Using Color Scheme

**Agent**: TSA J Leads
**Goal**: Triage the full pipeline by personal fit

With your Master ATS List complete and your resume in strong shape, go back to the full lead pool and scan every lead against your personal preferences:

| Color | Meaning | Action |
|-------|---------|--------|
| **Green** | Strong match: role, culture, comp, and values all align | Apply immediately |
| **Yellow** | Decent match: most criteria met, minor concerns | Apply if time permits |
| **Red** | Dead or rejected: expired, ghosted, or clearly misaligned | Archive, don't pursue |
| **Blue** | Accepted offer | Celebrate |
| No color | Not yet triaged | Needs review |

### What to scan for:

- Does the company culture match your stated values?
- Is the compensation within your target range?
- Is the work arrangement (remote/hybrid/onsite) acceptable?
- Are there red flags (recent layoffs, bad Glassdoor reviews, reposted 5 times)?
- Would you actually enjoy this job on a Tuesday afternoon?

### Key principle:

This step is about intentionality. You've built the tools (resume, ATS list, tracker). Now you decide where your energy goes. Color coding makes the decision visual and fast.

---

## Step 6: Mass Apply for All Relevant Leads

**Agent**: All agents coordinated by TSA Flo
**Goal**: Submit applications efficiently following all protocols

With your pipeline color-coded:

1. **Green leads first**: Apply to every green lead. For each one:
   - Use the tailored resume + cover letter pair (from Step 4)
   - If no custom pair exists yet, create one using the Master ATS List (fast, since you have the keywords)
   - Submit through the company's preferred channel
   - Log the application in the tracker (Status: Applied, date noted)
   - Capture the Job ID

2. **Yellow leads next**: Apply if you have capacity after greens are done

3. **Batch applications**: Platforms like Simplify Jobs allow one-click batch applications. Use these for volume, but ALWAYS log every application in the tracker. An untracked application is a wasted application.

### TSA Flo's role:

- Schedule application sessions (2-3 PDS blocks work well)
- Track how many applications per session
- Flag if the user is burning out or rushing
- Ensure quality stays high even during batch applying

### Key principle:

Volume matters, but tracked volume matters more. Every application should be traceable to a lead, a resume, a cover letter, and a Job ID.

---

## Step 7: Expand Past the JHS Master Doc

**Agent**: TSA J Search + TSA Port
**Goal**: Diversify your lead sources and build long-term presence

Once the initial pipeline is flowing and applications are going out, expand your reach:

### New lead sources:

- **LinkedIn**: Active networking, not just job listings. Connect with recruiters, engage with industry content, join relevant groups.
- **Specialty job boards**: Industry-specific boards often have higher-quality leads with less competition.
- **Referrals**: Ask your network. A referred application is 4x more likely to result in a hire.
- **Company career pages**: Many companies post roles on their own site before (or instead of) job boards.
- **Recruiters**: Engage staffing agencies that specialize in your field.

### Portfolio development (TSA Port):

As your application count grows, TSA Port helps you build a portfolio that reinforces your resume:

- **GitHub profile**: Clean README, pinned projects, contribution history
- **Portfolio site**: Start simple (GitHub Pages), grow it over time
- **LinkedIn presence**: Profile mirrors your resume narrative, recommendations section active
- **Case studies**: Turn your best work experiences into written portfolio pieces

### Key principle:

Steps 1-6 are the engine. Step 7 is the fuel. The more sources you add, the more leads flow in. The portfolio compounds: it makes every application slightly stronger because hiring managers can see evidence of your work.

---

## Putting It All Together

```
WEEK 1-2:  Steps 1-3 (Source, Build Resume, Create Master ATS List)
WEEK 3-4:  Steps 4-5 (Custom Materials, Color Scan Pipeline)
WEEK 5+:   Steps 6-7 (Mass Apply, Expand Sources, Build Portfolio)
ONGOING:   All agents active, pipeline flowing, lessons accumulating
```

The timeline compresses as you get faster. By Week 3, you should be able to go from "new lead" to "application submitted" in under an hour per lead.

TSA Flo keeps the rhythm. TSA J Search feeds the pipeline. TSA J Leads manages the flow. TSA Port produces the deliverables. Together, they form a complete job hunt operating system.

---

*Job Hunt Stack v2.0 | Workflow Guide*
*"Discipline is the bridge between goals and accomplishment."*
