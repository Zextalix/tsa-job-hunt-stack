# Job Hunt Stack: Session Lifecycle Walkthrough
### How the System Flows Together

---

## Why Sessions Matter

AI assistants don't remember previous conversations by default. Every time you start a new chat, the AI starts from zero. The Job Hunt Stack solves this with a session lifecycle: a repeatable process that loads your context at the start, captures new knowledge during the session, and archives everything at the end so the next session picks up where you left off.

This walkthrough explains how each piece connects.

---

## The Five Pillars

Your Job Hunt Stack runs on five interconnected documents:

| Pillar | File | Purpose |
|--------|------|---------|
| **Rules** | `Rules/Global Instructions.md` | Hard rules the AI must follow every session. Language preferences, file naming conventions, your values, formatting standards. These don't change often. |
| **Primer** | `Cold Start Primer.md` | The session boot sequence. Tells the AI what to read, in what order, and what the current state of your job hunt is. Updated at every session close. |
| **Identity** | `Identity/[User] Profile.md` | Your professional source of truth. Work history, skills, certifications, contact info. The AI references this for every deliverable it produces. |
| **Lessons** | `Master Lessons Learned.md` | A living log of insights from every session. "Don't use this job board, it's dead." "Company X ghosted after round 2." "This cover letter approach got a response." Grows over time. |
| **Archive** | `Archive Protocol.md` | The session close checklist. Makes sure nothing is lost, lessons are captured, and the next session has what it needs. |

---

## A Session from Start to Finish

### Step 1: Open a New Chat

Start a new conversation with your AI assistant. The AI knows nothing yet.

### Step 2: Load Global Instructions

If your AI platform supports system-level instructions (Claude's Cowork mode, custom GPTs, etc.), your Global Instructions are already loaded automatically. If not, paste the contents of `Rules/Global Instructions.md` at the start of the conversation.

**What this does:** Sets the ground rules. The AI now knows your file naming conventions, language preferences, and core values.

### Step 3: Load the Cold Start Primer

Give the AI the `Cold Start Primer.md` file. This is the most important step.

**What this does:** The Primer tells the AI:
- Who you are (points to your Profile)
- What agents are available and what they do
- What happened in the last session (Section 3: Current Status)
- What needs to happen next
- The checklist for getting fully operational

### Step 4: Load the Right Agent

Based on what you need to do today, load the relevant agent file:

| If you need to... | Load this agent |
|-------------------|----------------|
| Search for new job leads | `Agents/TSA J Search.md` |
| Triage and evaluate leads | `Agents/TSA J Leads.md` |
| Write cover letters or tailor resumes | `Agents/TSA Port.md` |
| Plan your schedule or coordinate tasks | `Agents/TSA Flo.md` |

You can load multiple agents in one session if needed, but start with the one that matches your primary task.

### Step 5: Do the Work

With context loaded, the AI is now fully operational. It knows your history, your priorities, your pipeline state, and exactly what protocols to follow. Work with it as a collaborator.

### Step 6: Capture Lessons Learned

Before closing the session, review what happened:

- Did anything unexpected come up?
- Did you discover a new job board that works well?
- Did a particular cover letter approach get a response?
- Did you learn something about a company or industry?
- Did a tool or process not work as expected?

Add these to `Master Lessons Learned.md`. Number them sequentially. The AI will read these at the start of every future session and avoid repeating mistakes.

### Step 7: Run the Archive Protocol

Follow the checklist in `Archive Protocol.md`:

1. Write a brief session summary (date, what was done, files created/modified)
2. Check for new Lessons Learned
3. Update the Cold Start Primer Section 3 (Current Status) with what changed
4. Save the session summary to `06_ARCHIVE/`
5. Note any carry-over tasks for next session

### Step 8: Done

Close the chat. Everything is archived. The next session will boot up right where you left off because the Cold Start Primer carries the state forward.

---

## How the Pieces Connect (Visual Flow)

```
SESSION START
│
├── Global Instructions (always active)
│   └── Sets: rules, naming, values, formatting
│
├── Cold Start Primer
│   ├── Points to: Identity Profile
│   ├── Points to: Agent files
│   ├── Contains: Last session status (Section 3)
│   └── Contains: Startup checklist
│
├── Agent File (loaded per task)
│   ├── References: Identity Profile (for user data)
│   ├── References: Tracker (for pipeline state)
│   └── Follows: Global Instructions rules
│
├── THE WORK HAPPENS HERE
│   ├── Produces: Cover letters, resumes, LeadCards
│   ├── Updates: Tracker spreadsheet
│   └── Generates: New insights
│
├── Lessons Learned (captured during/after work)
│   └── Feeds into: Future sessions via Cold Start Primer
│
└── Archive Protocol (session close)
    ├── Writes: Session summary to 06_ARCHIVE/
    ├── Updates: Cold Start Primer Section 3
    └── Carries forward: Everything the next session needs

SESSION END
```

---

## The DUPE and delete.me System

Over time, you'll accumulate duplicate files (older resume versions, copy-paste artifacts) and retired files (agents you've replaced, outdated LeadCards). Don't delete anything immediately.

- **DUPE/**: Put duplicate or superseded files here. Include a note about which file is the canonical (real) version.
- **delete.me/**: Put retired files here. Things you're confident you don't need anymore.

Both folders have a README explaining their purpose. Periodically review these folders and permanently delete what you're sure about. This two-stage system prevents accidental loss.

---

## Common Questions

**Q: Do I need to load everything every session?**
A: Global Instructions and Cold Start Primer, yes. Agent files, only the one(s) you need. It becomes second nature after 2-3 sessions.

**Q: What if I forget to run the Archive Protocol?**
A: Your next session won't have up-to-date status info. The AI might repeat work or miss context. It's worth the 5 minutes.

**Q: Can I use multiple agents in one session?**
A: Yes. Start with the primary agent, then load others as needed. TSA Flo is especially useful for coordinating multi-agent sessions.

**Q: What if my AI doesn't support file uploads?**
A: Copy-paste the file contents into the chat. The AI reads the text the same way regardless of delivery method.

**Q: How does this compare to just using an AI without the system?**
A: Without the system, every session starts from scratch. With it, every session builds on every previous session. Over 10+ sessions, the compounding knowledge makes a massive difference in application quality and search efficiency.

---

*Job Hunt Stack v2.0 | Walkthrough Guide*
*"Every session builds on the last. That's the whole point."*
