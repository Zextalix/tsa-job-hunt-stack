# Master Lessons Learned
### Job Hunt Stack - Living Knowledge Base

> **How to use:** Add lessons after every session. Number them sequentially. The AI reads this at session start and uses it to avoid repeating mistakes and to build on what works.

---

## Format

Each lesson follows this pattern:

```
### L[number]: [Short title]
**Session:** [date or session number]
**Context:** [What happened]
**Lesson:** [What we learned]
```

---

## Guiding Principles

These are meta-lessons that apply to every session:

1. **Always read the Cold Start Primer first.** It carries the state from the last session.
2. **Archive Protocol is not optional.** Skip it and the next session starts from scratch.
3. **Quantified achievements are sacred.** Never let the AI change your actual numbers.
4. **One session builds on the last.** That's the whole point of this system.

---

## Lessons

*(Your lessons start here. Add them as you go.)*

### L1: [Your first lesson will go here]
**Session:** [date]
**Context:** [What happened]
**Lesson:** [What you learned]

---

*Master Lessons Learned | Job Hunt Stack v2.0*
*"Every mistake documented is a mistake never repeated."*
