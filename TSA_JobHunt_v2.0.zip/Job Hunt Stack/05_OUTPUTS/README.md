# 05_OUTPUTS

Final deliverables are saved here: tailored resumes, portfolio exports, and any other finished work products.

**Resume naming convention:** `[Your Name] [RoleShorthand] [Company] Resume [Year].[ext]`

The matched cover letter for each resume lives in `03_COVER_LETTERS/`.
