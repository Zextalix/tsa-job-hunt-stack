# DUPE - Duplicate Files Staging Area

This folder holds duplicate and superseded files that are candidates for permanent deletion.

## What Goes Here

- Files with `(1)` or `copy` suffixes (auto-duplicates)
- Older versions of files that have been replaced by newer versions
- Sync artifacts and redundant copies

## Rules

- Nothing is permanently deleted from here without your explicit review
- When you move a file here, note which file is the canonical (real) version
- Review this folder periodically and permanently delete what you're confident about

## Current Contents

*(Empty at setup. Update this section as files are added.)*
