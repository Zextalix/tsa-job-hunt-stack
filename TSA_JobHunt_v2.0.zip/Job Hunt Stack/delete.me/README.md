# delete.me - Retired Files Staging Area

This folder holds retired files that are no longer needed but haven't been permanently deleted yet.

## What Goes Here

- Decommissioned documents
- Expired LeadCards for positions that were filled
- Temporary files (.tmp)
- Files you're confident you don't need but want a safety buffer before permanent deletion

## Rules

- Nothing is permanently deleted without your explicit review
- This is the last stop before permanent deletion
- When in doubt, leave it here for another session

## Current Contents

*(Empty at setup. Update this section as files are added.)*
