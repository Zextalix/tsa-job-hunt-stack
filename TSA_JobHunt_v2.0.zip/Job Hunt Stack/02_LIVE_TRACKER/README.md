# 02_LIVE_TRACKER

Your master job hunt tracker lives here.

**Primary file:** `Job Hunt Template.xlsx`

This spreadsheet contains multiple tabs:
- **Job Leads**: Your full pipeline of job leads with status, priority, and tracking columns
- **Job Search Websites**: List of job boards and aggregators to search (maintained by TSA J Search)

**Backup rule:** Before any major update, the AI should create a backup copy: `Job Hunt Template BACKUP YYYY-MM-DD.xlsx`

**Update naming:** After each session, the updated tracker is saved as: `Job Hunt Template [MM/DD/YYYY] Update.xlsx`
