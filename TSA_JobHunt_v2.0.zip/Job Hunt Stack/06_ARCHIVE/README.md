# 06_ARCHIVE

Session summaries and archived artifacts are saved here.

**Session summary naming:** `YYYY-MM-DD Session Summary [brief descriptor].md`

**Archived files:** Renamed with date prefix: `YYYY-MM-DD [OriginalFilename].[ext]`

Review the Archive Protocol for the full session close workflow.
