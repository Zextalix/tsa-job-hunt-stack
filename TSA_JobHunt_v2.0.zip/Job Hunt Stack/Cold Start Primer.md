# Cold Start Primer
### Job Hunt Stack - Universal Session Launch Document
*Version 2.0 | Public Release*

> **How to use this file:** Read it once at the start of any session. One read = fully operational. If you have Global Instructions loaded in your AI platform's system settings, those rules are already active. If not, read `Rules/Global Instructions.md` first.

---

## Section 1 - System Overview

This is the **Job Hunt Stack**, an AI-powered job hunting workflow system with four specialized agents. The workspace is owned and operated by:

**[Your Name Here]**
**[Your Title / Certification]**
**[Your Location]**

Update the above with your information after initial setup. See `Identity/[User] Profile.md` for your full professional profile.

---

## Section 2 - Agent Index

| Agent | File | Domain |
|-------|------|--------|
| TSA J Search | `Agents/TSA J Search.md` | Job board search, Top 10 leads, Job Info Cards |
| TSA J Leads | `Agents/TSA J Leads.md` | Lead triage, tracker logging, application pipeline |
| TSA Port | `Agents/TSA Port.md` | Portfolio, cover letters, resume tailoring, GitHub |
| TSA Flo | `Agents/TSA Flo.md` | Workflow coordination, scheduling, life flow |

---

## Section 3 - Current Workspace Status
*Update this section at every session close. Keep it brief.*

**Last updated:** [DATE] (Session 0, initial setup)
**Status:** Workspace initialized. No applications submitted yet.
**Next step:** Load TSA J Search and begin Step 1 of the Workflow (sourcing leads).
**Carry-over:** None.

---

## Section 4 - Where to Find X

| Looking for | Go to |
|-------------|-------|
| Your professional profile and work history | `Identity/[User] Profile.md` |
| Hard rules (naming, formatting, values) | `Rules/Global Instructions.md` |
| Lessons from previous sessions | `Master Lessons Learned.md` |
| Session close workflow | `Archive Protocol.md` |
| Job tracker spreadsheet | `02_LIVE_TRACKER/Job Hunt Template.xlsx` |
| Cover letters | `03_COVER_LETTERS/` |
| Lead research cards | `04_JOB_LEADS/` |
| Final deliverables (tailored resumes) | `05_OUTPUTS/` |
| Archived session records | `06_ARCHIVE/` |
| 7-step workflow guide | `docs/WORKFLOW.md` |
| Session lifecycle walkthrough | `docs/WALKTHROUGH.md` |

---

## Section 5 - Session Startup Checklist

1. Read this primer (you just did)
2. If Global Instructions are not loaded in system settings, read `Rules/Global Instructions.md`
3. Check `Master Lessons Learned.md` for insights from previous sessions
4. Identify today's task and load the relevant agent file from `Agents/`
5. Scan for any unread reference files relevant to the task
6. State your scope: what you've read, what you haven't, what you're about to do
7. Show a brief plan, then wait for the user's approval before executing
8. At session close: run the Archive Protocol; update Section 3 above

---

*"One read. Full ops. Let's flow."*
