# Professional Profile
### Your Source of Truth for All Application Materials

> **Instructions:** Fill in every section below. The more detail you provide (especially quantified achievements), the better your AI agents will perform. This file is referenced by every agent in the system.

---

## Personal Information

| Field | Value |
|-------|-------|
| Full Name | |
| Professional Title | |
| Certifications | |
| Location | |
| Email | |
| Phone | |
| LinkedIn | |
| GitHub | |
| Portfolio URL | |

---

## Professional Summary

*(2-3 sentences describing who you are professionally. This becomes the basis for your resume summary and cover letter opening.)*



---

## Work History (Reverse Chronological)

### [Job Title] | [Start Date] - [End Date]
**[Company Name]** | [Location]

- [Achievement with quantified result - e.g., "Led 12-person team to deliver project 3 weeks ahead of schedule"]
- [Achievement with metrics - e.g., "Reduced operational costs by 25% through process optimization"]
- [Achievement with impact - e.g., "Designed onboarding program adopted by 3 regional offices"]

### [Job Title] | [Start Date] - [End Date]
**[Company Name]** | [Location]

- [Achievement]
- [Achievement]
- [Achievement]

*(Copy this template block for each role. Aim for 3-5 bullet points per role, each with a quantified result.)*

---

## Education

| Degree | Institution | Location | Year |
|--------|------------|----------|------|
| | | | |
| | | | |

---

## Skills Inventory

### Technical Skills
*(Tools, platforms, methodologies you use)*



### Soft Skills
*(Leadership, communication, problem-solving approaches)*



### Certifications & Training
*(Professional certifications, courses, workshops)*

| Certification | Issuing Body | Date | Verification Link |
|--------------|-------------|------|-------------------|
| | | | |

---

## Language Proficiency

*(If you speak multiple languages, be specific about each one.)*

| Language | Proficiency Level | Context |
|----------|------------------|---------|
| | | |

---

## Values Statement

*(What matters to you in a workplace? What kind of culture do you thrive in? This drives how agents evaluate leads and calibrate your application tone.)*

**What I value most:**


**What drains me:**


**My ideal work environment:**


---

## Target Roles

*(What roles are you pursuing? This helps agents filter and prioritize leads.)*

| Role Title | Shorthand | Notes |
|-----------|-----------|-------|
| | | |
| | | |

---

## Additional Context

*(Anything else the AI should know: career gaps to address, relocation plans, visa status, industry preferences, etc.)*



---

*Job Hunt Stack v2.0 | User Profile Template*
*"The more the AI knows about you, the better it can represent you."*
