# 03_COVER_LETTERS

Cover letters produced by TSA Port are saved here.

**Naming convention:** `[Your Name] [RoleShorthand] [Company] Cover Letter [Year].[ext]`

Every cover letter is produced in both `.docx` and `.pdf` format. The matched resume lives in `05_OUTPUTS/`.
