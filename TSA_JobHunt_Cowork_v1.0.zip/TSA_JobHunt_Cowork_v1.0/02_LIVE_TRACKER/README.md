# 02_LIVE_TRACKER — Folder Instructions

## Contents
- `Job_Hunt_Template.xlsx` — The master job hunt tracking spreadsheet

## CRITICAL Rules for This Folder
- **NEVER overwrite the original file** without first creating a backup named
  `Job_Hunt_Template_BACKUP_YYYY-MM-DD.xlsx`
- Always preserve all existing formatting, formulas, and tab structure
- When adding new job leads, append to the BOTTOM of the Job Leads tab — never insert rows
  in the middle
- Do not delete any existing rows — use the Status column to mark leads as inactive

## Tab Reference
| Tab Name | Purpose |
|----------|---------|
| Job Leads | Main tracking table — one row per job lead |
| Job Search Websites | List of job boards to search |
| Resume Optimization | ATS tools and resume scoring resources |
| Recruiter Screen Checklist | Questions to ask during recruiter calls |
| Events | Networking events and conferences |
| Resources | Misc job search resources |
| Agencies | Recruiting agencies |
| Interview Prep | Interview preparation resources |
| Maslows Hierarchy | Basic needs and stability resources |

## Update Cadence
- TSA J Leads updates this file after every job search session
- TSA J Search reads the Job Search Websites tab before every search
- Always save a date-stamped backup before making batch changes
