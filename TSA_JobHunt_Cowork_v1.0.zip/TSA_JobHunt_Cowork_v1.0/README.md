# TSA Job Hunt Stack — Cowork Edition
**A values-aligned, AI-powered job hunting workflow for Claude Cowork users**

*Created by Flo Masta Jay (James Kelly, PMP®) | Aquarius Aeon Medias LLC*
*Part of the Worthy to Wealthy (W2W) Project — Philanthropic AI Workflows*

---

## What Is This?
The TSA Job Hunt Stack is a structured AI workflow system that turns Claude Cowork into a
coordinated team of job search specialists. Instead of asking Claude one question at a time,
you load this stack and get four specialized AI assistants working in sync:

| Assistant | What It Does |
|-----------|-------------|
| **TSA J Search** | Scans job boards, finds your Top 10 leads, prioritizes by values fit |
| **TSA J Leads** | Triages leads, updates your tracker, prepares your application pipeline |
| **TSA Port** | Writes tailored cover letters, adapts your resume, builds your portfolio |
| **TSA Flo** | Coordinates your workflow using PMBOK 7 principles, plans your day/week |

---

## Who Is This For?
This edition is designed for users with a **paid Claude plan (Pro, Max, Team, or Enterprise)**
who have access to **Claude Cowork**. Cowork gives Claude access to your local files, enabling
the full power of this stack — automated weekly searches, live tracker updates, and scheduled tasks.

> If you're on the **free Claude plan**, use the **TSA Job Hunt Stack — Free Edition** instead.
> It contains a Prompt Library version of these same assistants, formatted for copy-paste use
> in the standard Claude.ai chat.

---

## Before You Start — Setup Checklist

Complete these steps before your first Cowork session:

- [ ] **1. Fill out your profile**
  Open `00_CONTEXT/MY_PROFILE_TEMPLATE.md` and replace all placeholders with your info.
  This is the single most important file — all assistants read it first.

- [ ] **2. Set your ATS keywords**
  Open `00_CONTEXT/ATS_KEYWORDS_TEMPLATE.md` and fill in your target keywords and role.

- [ ] **3. Load Global Instructions**
  Open `01_ASSISTANTS/GLOBAL_INSTRUCTIONS.md`, copy its full contents, and paste into:
  **Cowork → Settings → Global Instructions**

- [ ] **4. Explore the tracker**
  Open `02_LIVE_TRACKER/Job_Hunt_Template.xlsx`. Review all tabs. Add your preferred job
  boards to the Job Search Websites tab. Familiarize yourself with the Job Leads tab columns.

- [ ] **5. Run your first session**
  Open Cowork, select this folder as your workspace, and paste the contents of
  `01_ASSISTANTS/COWORK_FIRST_PROMPT.md` as your first message.

---

## How the Stack Works — Session by Session

### First-Ever Session
Paste `COWORK_FIRST_PROMPT.md` → Claude reads all files → Confirms understanding → You begin.

### Every Session After That
Paste `COWORK_LAUNCH_PROMPT.md` → Claude re-initializes → You give your first task.

### Typical Weekly Workflow
```
SUNDAY (Week Start)
└── TSA J Search: Scan job boards → Top 10 leads → Save to 04_JOB_LEADS/

MONDAY–THURSDAY
├── TSA J Leads: Triage leads → Update tracker → Prioritize Top 3
└── TSA Port: Tailor resume + write cover letter for Top 3

FRIDAY (Week End)
└── TSA Flo: Weekly retrospective → What worked? What to adjust? Plan next week.

ANY DAY (On-Demand)
├── TSA Port: Generate cover letter for a specific lead
├── TSA J Search: Check ATS score on a specific resume/JD pair
└── TSA Flo: Build today's daily sprint plan
```

---

## Folder Structure
```
TSA_JobHunt_Cowork_v1.0/
├── README.md                        ← You are here
├── 00_CONTEXT/
│   ├── MY_PROFILE_TEMPLATE.md       ← Fill this in first
│   └── ATS_KEYWORDS_TEMPLATE.md     ← Fill this in second
├── 01_ASSISTANTS/
│   ├── GLOBAL_INSTRUCTIONS.md       ← Copy to Cowork Global Settings
│   ├── COWORK_FIRST_PROMPT.md       ← Paste on your first ever session
│   ├── COWORK_LAUNCH_PROMPT.md      ← Paste at the start of every session
│   ├── TSA_J_Search.md              ← Job search assistant instructions
│   ├── TSA_J_Leads.md               ← Lead triage assistant instructions
│   ├── TSA_Flo.md                   ← Workflow coordinator instructions
│   ├── TSA_Port.md                  ← Portfolio & cover letter instructions
│   └── RESUME_REVISION_STACK.md     ← External ATS tool workflow guide
├── 02_LIVE_TRACKER/
│   ├── Job_Hunt_Template.xlsx        ← Your live job tracking spreadsheet
│   └── README.md
├── 03_COVER_LETTERS/                ← Generated cover letters saved here
│   └── README.md
├── 04_JOB_LEADS/                    ← Job info cards (LeadCards) saved here
│   └── README.md
└── 05_OUTPUTS/                      ← Final resumes and other deliverables
    └── README.md
```

---

## Using Scheduled Tasks

Cowork supports automated scheduled tasks. Once your stack is initialized, you can schedule:

- **Weekly Sunday Job Search** — TSA J Search scans boards every Sunday automatically
- **Weekly Friday Review** — TSA Flo runs a retrospective every Friday
- **Custom reminders** — Follow-up prompts for active applications

See `01_ASSISTANTS/COWORK_LAUNCH_PROMPT.md` for the exact prompt text to use for each.

---

## Values This Stack Is Built On

This stack was designed with the following professional philosophy baked in — customize freely:

- **Theory Z management** (William Ouchi): Prioritize employers who treat staff as whole humans,
  invest in long-term growth, and support collective wellbeing
- **Servant leadership**: Seek cultures of mutual respect and flat hierarchy
- **PMBOK 7th Edition principles**: Value delivery, adaptability, and systems thinking applied
  to daily workflow and weekly planning
- **Sustainable pace**: A good job search is a marathon, not a sprint — the stack is built to
  support consistent effort without burnout

> **Creator's note:** This stack was originally built by a Theory Z-motivated, highly sensitive
> professional who believes that the right job is one that honors the whole person. You are
> encouraged to make it your own. Customize the values alignment criteria, matching rubric,
> and daily planning templates to fit your life.

---

## Attribution & IP Notice

**Stack created by:** James Kelly, PMP® | Flo Masta Jay | Aquarius Aeon Medias LLC
**GitHub:** https://github.com/Zextalix
**Part of the W2W (Worthy to Wealthy) Project** — a philanthropic initiative to make
professional-grade AI workflows accessible to everyone.

This stack is shared freely for personal and non-commercial use. The following elements
have been intentionally removed from this public version to protect intellectual property:
- ETF™ (Eternal Truth Framework) — available at https://snowfieldrhapsody.wordpress.com
- AIRI™ Method — available at https://snowfieldrhapsody.wordpress.com
- Lifestyle Design Gamification elements

If you find this stack valuable, consider sharing it with someone who needs it.
*"From worthy to wealthy — one flow at a time."*

---

*TSA Job Hunt Stack — Cowork Edition v1.0 | Released 2026*
