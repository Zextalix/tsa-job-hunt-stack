# COWORK FIRST PROMPT — Paste This Into Cowork On Your Very First Session

---

Hey Cowork! Please do the following to initialize the TSA Job Hunt Stack:

1. Read `README.md` in the root of this folder
2. Read `00_CONTEXT/MY_PROFILE_TEMPLATE.md` — this is my professional profile
3. Read all files in `01_ASSISTANTS/`
4. Read the `README.md` files in subfolders 02 through 05

Then confirm you understand the following by summarizing back to me:
- Who I am (from MY_PROFILE_TEMPLATE.md)
- My job search priorities and values alignment criteria
- The role and purpose of each TSA assistant (J Search, J Leads, Flo, Port)
- The folder structure and what goes where

After confirming, tell me you are ready to receive my first task.

Do NOT start any tasks until I give you the go-ahead after your confirmation summary.

---

## SETUP CHECKLIST (Complete Before First Use)
- [ ] Fill out `00_CONTEXT/MY_PROFILE_TEMPLATE.md` with your personal and professional info
- [ ] Fill out `00_CONTEXT/ATS_KEYWORDS_TEMPLATE.md` with your target keywords
- [ ] Review `01_ASSISTANTS/GLOBAL_INSTRUCTIONS.md` and copy it into Cowork Global Settings
- [ ] Open `02_LIVE_TRACKER/Job_Hunt_Template.xlsx` and familiarize yourself with the tabs
- [ ] Bookmark the Resume Revision Stack tools from the Resume Optimization tab

---
