# Resume Revision AI Website Stack
*Reference guide for optimizing your resume using external web tools*
*Part of the TSA Job Hunt Stack workflow — runs in parallel with TSA J Leads and TSA J Search*

---

## Purpose
This is NOT an AI assistant — it is a web tool workflow to run resumes through external
ATS/SEO optimization sites. Run this stack whenever a new job lead is prioritized or
after any resume update. Results feed back into TSA J Search and TSA J Leads.

---

## Tool Order (Run in This Sequence)

### Step 1 — Resume Optimizer
**URL:** See `02_LIVE_TRACKER/Job_Hunt_Template.xlsx` → Resume Optimization tab
**Use for:** Initial resume assessment — evaluates Impact, Brevity, Style, and Soft Skills
**Note:** Run again as your FINAL step after all other tools to compare improvement vs. baseline

### Step 2 — Resume Builder (Teal)
**URL:** See Resume Optimization tab
**Use for:**
- Test the Resume Optimizer output against specific job lead descriptions using Job Match tool
- Use LinkedIn profile data in drag-and-drop editor to select experiences per resume version
- Access ATS-ready resume templates with customizable fonts, layout, and spacing
- Generate matching cover letters

### Step 3 — Jobscan
**URL:** See Resume Optimization tab
**Use for:** Combined ATS + SEO test; cross-check against both Step 1 and Step 2 outputs
**Note:** Combines functionality of both above tools — different algorithms produce different
style outputs; keep the version you prefer
**Bonus:** Chrome extension available for in-browser resume review

### Step 4 — Simplify
**URL:** See Resume Optimization tab
**Use for:** Final deep test with the most in-depth job-hunting tools
- Built-in job matching (free — charges companies for advertising, not users)
- Autofill repetitive job application questions via Copilot extension
- Job tracking (can use alongside Job Hunt Template)
- Cover letter assistance

---

## Workflow Notes
- You can screenshot ANY output (job match results, application questions, scores, etc.) and paste
  directly into TSA J Search or TSA J Leads to be properly tracked in the Job Hunt Template
- All four tools have job tracking and cover letter features — use them as supplements,
  not replacements, for the TSA Stack
- Try updated resumes through all four tools when testing new resume variations

---

## Output Flow
```
Resume Revision Stack
        │
        ├──> TSA J Search   (updated resume improves job matching accuracy)
        │
        └──> TSA J Leads    (resume updates logged in Notes column)
```

---

## Tips
- Run Step 1 (Resume Optimizer) both FIRST and LAST to measure improvement
- Adjust this stack freely once you have a feel for each tool's output style
- Keep your preferred version of any AI-generated resume variation; all algorithms differ
- **Target:** 70%+ ATS keyword match; **Bare minimum:** 60%

*Resource links are maintained in the Resume Optimization tab of `02_LIVE_TRACKER/Job_Hunt_Template.xlsx`*
