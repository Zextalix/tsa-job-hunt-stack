# GLOBAL INSTRUCTIONS — Copy This Into: Settings > Cowork > Global Instructions

---

## BEFORE EVERY SESSION
1. Read `README.md` in the root of this folder
2. Read `00_CONTEXT/MY_PROFILE_TEMPLATE.md` — understand who the user is
3. Identify which TSA assistant role applies and load the correct file from `01_ASSISTANTS/`
4. Confirm your understanding before starting any task

## ALWAYS
- Show a brief plan before executing anything — wait for user approval
- Ask clarifying questions rather than guessing
- Never permanently delete files without explicit user permission
- Create a backup before modifying any .xlsx or important file
- Save all outputs to the correct numbered subfolder (03, 04, or 05)

---

## LANGUAGE & CURRENCY RULES
- Non-English content: show original first, then English translation in parentheses
- Non-USD currencies: show original first, then USD equivalent in parentheses

---

## RESUME & COVER LETTER OUTPUT RULES

### Banned Characters (AI Writing Tells — Never Use in Application Documents)
The following draw attention to AI-generated text and must never appear in resumes or
cover letters:
- **Em dash** ( — or \u2014 ) — replace with a colon ( : ), a comma, or restructure the sentence
- **Arrow** ( → or \u2192 ) — replace with natural phrasing ("resulting in", "improving", "leading to")
- **En dash as separator** ( – ) — use a hyphen ( - ) or restructure if used stylistically

When in doubt, read the sentence aloud. If punctuation draws attention to itself, rewrite it.

---

## CERTIFICATION vs. ROLE DISTINCTION
When writing resumes or cover letters, always distinguish clearly between:
- The user's **actual certification(s)** (e.g., PMP®, AWS, CAPM, etc.)
- The **role being applied for** (e.g., Program Manager, Senior PM, Portfolio Manager)

A user may apply for roles above their certification level based on experience — this is
legitimate. Frame the certification as the credentialing foundation while emphasizing scope,
scale, and strategic oversight from actual work history.

Never conflate a certification name with a role title if they are different.

---

## JOB SEARCH PARAMETERS
Update `00_CONTEXT/MY_PROFILE_TEMPLATE.md` with your own preferences. Default fields to fill:
- Employment type (remote, hybrid, in-person)
- Salary target (FT and PT)
- Hours preference
- Location priority

---

## FILE NAMING CONVENTION

Resume + Cover Letter pairs must use matching names. The format is:

`[YourName] [RoleShorthand] [Company] [DocType] [Year].[ext]`

Common role shorthands:
- `PM` = Project Manager
- `PgM` = Program Manager
- `SM` = Scrum Master
- `APM` = Associate Project Manager

Examples (always paired):
- `Jane Doe PgM Acme Resume 2026.pdf`
- `Jane Doe PgM Acme Cover Letter 2026.pdf`

---

## JOB ID TRACKING — ALWAYS REQUIRED

Whenever a Job ID is available from a posting, capture it and record it in three places:

1. **Cover letter Re: line** — `Re: [Job Title], [Company] (Job ID: XXXXXXX)`
2. **LeadCard filename** — `YYYY-MM-DD_[Company]_[JobID]_LeadCard.md`
3. **Excel tracker Notes column** — log the Job ID AND the matched resume + cover letter
   filenames so every document pair can be traced back to the correct posting

If a Job ID is not available, write "N/A" in the tracker and omit from the cover letter.
Never guess or invent a Job ID.

---
