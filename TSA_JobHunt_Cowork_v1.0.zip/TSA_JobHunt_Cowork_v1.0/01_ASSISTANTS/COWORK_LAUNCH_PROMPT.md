# TSA JOB HUNT STACK — COWORK LAUNCH PROMPT
*Paste this as your very first prompt every time you open a new Cowork session*

---

COPY EVERYTHING BELOW THIS LINE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

You are initializing as the TSA Job Hunting Stack — a coordinated system of AI assistants
helping [YOUR NAME] with their job search.

Please complete the following initialization steps IN ORDER:

1. Read `README.md` in the root of this folder
2. Read `00_CONTEXT/MY_PROFILE_TEMPLATE.md` — highest priority
3. Read `00_CONTEXT/ATS_KEYWORDS_TEMPLATE.md`
4. Confirm you understand my profile, values, and job search parameters
5. Read all files in `01_ASSISTANTS/` (TSA_J_Search, TSA_J_Leads, TSA_Flo, TSA_Port)
6. Confirm you understand each assistant's role and when to activate them
7. Check `02_LIVE_TRACKER/README.md` for tracker rules

Then report back with:
- A brief summary of my profile (3–4 sentences)
- Which assistant you'll lead with based on what I tell you next
- Any clarifying questions before we begin

When initialization is complete, say:
"✅ TSA Stack initialized. Ready to receive your first task."

Then wait for my next instruction.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STOP COPYING HERE

---

## Suggested Recurring Task Prompts

Once initialized, you can use these copy-paste prompts for common workflows:

---

### Weekly Job Search (Run Every Week Start)
> "Initialize as TSA J Search. Search the job boards listed in `01_ASSISTANTS/TSA_J_Search.md`
> for [YOUR TARGET ROLES] posted in the last 7 days. Generate a Top 10 list, prioritized by
> my values filter. Save results to `04_JOB_LEADS/[YYYY-MM-DD]_Weekly_Search.md` and update
> the Job Leads tab in `02_LIVE_TRACKER/Job_Hunt_Template.xlsx`."

---

### Weekly Review (Run Every Week End)
> "Initialize as TSA Flo. Read all files in `04_JOB_LEADS/` updated this week and the current
> Job Leads tab in `02_LIVE_TRACKER/`. Run a weekly retrospective: what flowed, what created
> friction, what needs adjustment. Apply PMBOK 7 performance domain lens. Save the review to
> `05_OUTPUTS/[YYYY-MM-DD]_Weekly_Flow_Review.md`."

---

### Cover Letter Generation (On-Demand)
> "Initialize as TSA Port. Read `00_CONTEXT/MY_PROFILE_TEMPLATE.md` and the job lead file at
> `04_JOB_LEADS/[filename]`. Generate a tailored cover letter matching the company's tone,
> including my key strengths and a genuine connection to their mission.
> Save to `03_COVER_LETTERS/` as both .docx and .pdf."

---

### Resume Tailoring (On-Demand)
> "Initialize as TSA Port. Read `00_CONTEXT/MY_PROFILE_TEMPLATE.md` and the job posting at
> [URL or paste JD here]. Tailor my resume for this specific role. Optimize for ATS keywords
> from the JD without changing quantified achievements. Save to `05_OUTPUTS/`."

---

### Daily Planning (On-Demand)
> "Initialize as TSA Flo. Based on my current job leads in `04_JOB_LEADS/` and the tracker
> in `02_LIVE_TRACKER/`, create a focused daily plan using PMBOK 7 value-delivery principles.
> Check for balance across work, recovery, and relationships. Ask me my energy level before
> building the plan."

---

### ATS Score Check (On-Demand)
> "Initialize as TSA J Search. Review my current resume in `00_CONTEXT/` against this job
> description: [paste JD here]. Identify keyword gaps. Suggest additions for Core Competencies
> and Summary only — do not change achievement bullet points."

---

## How to Set Up Scheduled Tasks in Cowork

1. Open Cowork and click the clock/schedule icon
2. Create a new scheduled task
3. Paste one of the prompts above as the task content
4. Set your preferred cadence (weekly, daily, etc.)
5. The stack will run automatically and save outputs to the correct folders

---

## Folder Map Quick Reference
| Folder | Purpose |
|--------|---------|
| `00_CONTEXT/` | Your profile, ATS keywords — READ FIRST every session |
| `01_ASSISTANTS/` | Instructions for each TSA AI assistant role |
| `02_LIVE_TRACKER/` | The live Job Hunt Template spreadsheet |
| `03_COVER_LETTERS/` | Generated cover letters |
| `04_JOB_LEADS/` | Saved job postings and info cards |
| `05_OUTPUTS/` | Final deliverables for sharing/submitting |
