# ATS Keywords — Fill This In For Your Job Search

## Purpose
Use this file to track which ATS (Applicant Tracking System) keywords matter most for your
target roles. TSA J Search and TSA Port will reference this when optimizing your resume.

**Target:** 70%+ keyword match on Simplify or Jobscan
**Bare minimum:** 60%

> Never edit work history bullet points to force keywords. Only adjust Core Competencies,
> the Summary, and cover letter narrative language. Keywords must fit naturally.

---

## Always-On Keywords — Your Core Identity
*These reflect your certification and consistent career identity. Keep in every resume.*

| Keyword | Where to Place |
|---------|---------------|
| [e.g., Project Management] | Summary, Core Competencies |
| [e.g., PMP® / Your Certification] | Summary, Certification section |
| [e.g., Agile / Scrum / Kanban] | Core Competencies |
| [e.g., Stakeholder Management] | Core Competencies |
| [e.g., Cross-functional Teams] | Core Competencies |
| [Your core tool, e.g., JIRA] | Core Competencies / Tools |

---

## High Priority — Rotate In as Needed
*Include at least 3–4 of these per tailored resume based on the job description.*

| Keyword | PM-Aligned Phrasing | Notes |
|---------|---------------------|-------|
| [Keyword] | [How to phrase it] | [When to use] |
| [Keyword] | [How to phrase it] | [When to use] |
| [Keyword] | [How to phrase it] | [When to use] |
| [Keyword] | [How to phrase it] | [When to use] |

---

## Medium Priority — Include When Relevant
*Swap in when the JD specifically mentions these or when scores need boosting past 70%.*

[keyword 1] · [keyword 2] · [keyword 3] · [keyword 4] · [keyword 5]

---

## Role-Specific Keyword Log
*Track ATS scores by application here. Screenshot Simplify/Jobscan results after each check.*

### [Company Name] — [Job Title] (Job ID: [ID or N/A])
- **Date checked:** [MM/DD/YYYY]
- **Score:** [X/Y] → [%] ([Strong/Needs Work])
- **Matched:** [keyword1, keyword2]
- **Missing / Added:** [keyword3, keyword4]
- **Skipped:** [keyword] (reason: not relevant)
- **Target score after update:** 70%+
- **Matched resume file:** [filename.docx]
- **Matched cover letter file:** [filename.docx]

---

## Standing Rules
1. **Never edit work history bullets** to force keywords — only Core Competencies and Summary
2. **Format:** Pipe-separated in Core Competencies for clean ATS parsing
3. **Verify on Simplify before every submission** — target 70%+, bare minimum 60%
4. **Log each application's score** in the Role-Specific Keyword Log above
5. **Keep phrasing professional** — keywords must fit naturally in your professional lexicon

---

## Approved Core Competencies Block (Your Standard Template)
*Build your own version here — update for each role as needed.*

```
[Competency 1]  |  [Competency 2]  |  [Competency 3]  |
[Competency 4]  |  [Competency 5]  |  [Competency 6]  |
[Competency 7]  |  [Competency 8]  |  [Competency 9]
```
