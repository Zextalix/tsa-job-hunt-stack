# MY PROFILE — Fill This In Before Your First Session

*This file is the single source of truth for who you are. All TSA assistants read this first.*
*Replace every [PLACEHOLDER] with your actual information.*

---

## Personal Info
- **Name:** [YOUR FULL NAME + CREDENTIALS, e.g., Jane Doe, PMP®]
- **Location:** [City, State/Country]
- **Languages:** [e.g., English (native), Spanish (conversational)]
- **LinkedIn:** [https://linkedin.com/in/yourprofile]
- **GitHub / Portfolio:** [URL if applicable]
- **Email:** [your@email.com]

---

## Professional Identity
- **Current Title / Brand:** [e.g., Founder, XYZ Consulting | Project Manager | AI Generalist]
- **Certifications:** [e.g., PMP® (PMI, 2023), AWS Solutions Architect, Scrum Master (CSM)]
- **Specializations:** [e.g., Agile PM, Workflow Architecture, Stakeholder Management]
- **Key Strengths:** [e.g., Cross-functional team leadership, remote team coordination, process improvement]

---

## Work History Summary
| Role | Company | Period | Location |
|------|---------|--------|----------|
| [Job Title] | [Company] | [Start – End] | [City/Remote] |
| [Job Title] | [Company] | [Start – End] | [City/Remote] |
| [Job Title] | [Company] | [Start – End] | [City/Remote] |

---

## Key Achievements (Quantified — Use These in Resumes & Cover Letters)
- [Achievement with numbers, e.g., "Led 15-person team → 40% improvement in delivery speed"]
- [Achievement with numbers]
- [Achievement with numbers]
- [Achievement with numbers]

---

## Education
- [Degree, Major — Institution, City (Year)]
- [Any relevant coursework, certifications, or training]

---

## Job Search Parameters
- **Employment Type:** [Remote only / Open to hybrid / In-person preferred]
- **Salary Target (FT):** [e.g., $60,000+ USD/year]
- **Salary Target (PT/Contract):** [e.g., $30–40/hr]
- **Hours Preference:** [e.g., 20–30 hrs/week / 40 hrs/week]
- **Location Priority:** [e.g., Pacific timezone → East Coast → Remote anywhere]

---

## Values & Culture Alignment
*What matters most to you in a workplace? Customize this for TSA J Search and TSA J Leads.*

- [ ] Theory Z culture (long-term employment, collective decision-making, holistic employee care)
- [ ] Servant leadership / flat org structure
- [ ] Mission-driven / nonprofit / social impact focus
- [ ] Remote-first with async communication norms
- [ ] Flexible hours / results-oriented work environment (ROWE)
- [ ] DEI-forward, inclusive culture
- [ ] Other: [describe your values]

**Red flags to avoid:**
- [e.g., Hustle culture / crunch without compensation]
- [e.g., Rigid in-office requirements]
- [e.g., Companies with frequent mass layoffs]

---

## Skills (ATS Keywords)
*List your key skills here — TSA J Search will use these for ATS optimization.*

[Skill 1] | [Skill 2] | [Skill 3] | [Skill 4] | [Skill 5]
[Skill 6] | [Skill 7] | [Skill 8] | [Skill 9] | [Skill 10]

---

## Active Projects / Side Work
- **[Project Name]** — [Brief description and current status]
- **[Project Name]** — [Brief description and current status]

---

## Notes for Assistants
*Anything else the TSA assistants should always remember about you:*

> This job hunt stack was originally created by a Theory Z-motivated professional who values
> holistic wellbeing alongside career productivity. Customize this file to reflect your own
> values and circumstances. The more detail you provide here, the better calibrated the
> assistants will be to your needs.

[Add any personal notes here — e.g., preferred communication style, scheduling constraints,
industry background, specific companies to avoid, etc.]
