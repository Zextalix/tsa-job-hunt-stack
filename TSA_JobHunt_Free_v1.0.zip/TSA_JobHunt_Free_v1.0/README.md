# TSA Job Hunt Stack — Free Edition
**A values-aligned, AI-powered job hunting workflow — no paid subscriptions required**

*Created by Flo Masta Jay (James Kelly, PMP®) | Aquarius Aeon Medias LLC*
*Part of the Worthy to Wealthy (W2W) Project — Philanthropic AI Workflows*

---

## What Is This?

The TSA Job Hunt Stack is a professional-grade job search system built for people who
deserve access to powerful career tools — regardless of income.

This free edition gives you **ready-to-paste AI prompts** that work with the **free
Claude.ai chat interface**. No Cowork subscription needed. No paid tools required.
Even one hour of library computer time is enough to run a productive session.

---

## What You Get

```
TSA_JobHunt_Free_v1.0/
├── 00_START_HERE.md            ← Read this first — complete setup guide
├── 01_MY_PROFILE_TEMPLATE.md  ← Fill this in — tells Claude who you are
├── 02_ATS_KEYWORDS_TEMPLATE.md ← Track your resume keywords here
├── PROMPTS/
│   ├── PROMPT_01_JOB_SEARCH.md    ← Find your Top 10 leads
│   ├── PROMPT_02_LEAD_TRIAGE.md   ← Evaluate and prioritize leads
│   ├── PROMPT_03_COVER_LETTER.md  ← Write tailored cover letters
│   └── PROMPT_04_WEEKLY_FLOW.md   ← Plan your week + retrospectives
├── TRACKER/
│   └── Job_Hunt_Template.xlsx     ← Your live job tracking spreadsheet
└── FREE_TOOLS_GUIDE.md           ← Teal, Simplify, Jobscan — how to use them
```

---

## Quick Start (5 Steps)

1. **Read** `00_START_HERE.md` — full instructions, including a 1-hour library session plan
2. **Fill out** `01_MY_PROFILE_TEMPLATE.md` with your information
3. **Open** `TRACKER/Job_Hunt_Template.xlsx` in Excel or Google Sheets
4. **Go to** claude.ai → create a free account (or log in)
5. **Open** `PROMPTS/PROMPT_01_JOB_SEARCH.md` → copy the prompt → paste into Claude

---

## The 4 Prompts at a Glance

| Prompt | What It Does | When to Use |
|--------|-------------|-------------|
| PROMPT 01 — Job Search | Finds your Top 10 leads + Job Info Cards | Week start / on-demand |
| PROMPT 02 — Lead Triage | Scores and ranks your leads | After Prompt 01 |
| PROMPT 03 — Cover Letter | Writes tailored cover letters | After Prompt 02, per lead |
| PROMPT 04 — Weekly Flow | Plans your week + retrospectives | Any time |

---

## What You'll Need (All Free)

| Tool | Purpose |
|------|---------|
| Claude.ai (free) | Your AI assistant |
| Simplify Jobs | ATS keyword check + application autofill |
| Teal HQ | Resume builder + job match scoring |
| Jobscan | ATS + SEO score cross-check |
| Excel or Google Sheets | Open the Job Hunt Template tracker |

---

## Want More Power?

If you upgrade to a paid Claude plan (Pro, Max, Team, or Enterprise), the
**TSA Job Hunt Stack — Cowork Edition** gives you:
- Automatic file reading (no copy-paste needed between sessions)
- Scheduled weekly job searches (runs automatically)
- Live tracker updates from Claude
- Full multi-session workflow coordination

Both editions available at: https://github.com/Zextalix

---

## Attribution & IP Notice

**Stack created by:** James Kelly, PMP® | Flo Masta Jay | Aquarius Aeon Medias LLC
**GitHub:** https://github.com/Zextalix
**Part of the W2W (Worthy to Wealthy) Project** — philanthropic AI workflows for everyone.

The ETF™ and AIRI™ frameworks that inspired parts of this stack's philosophy are
available free at: https://snowfieldrhapsody.wordpress.com

If this helped you, please share it with someone who needs it.
*"From worthy to wealthy — one flow at a time."*

---

*TSA Job Hunt Stack — Free Edition v1.0 | Released 2026*
