# TSA Job Hunt Stack — Free Edition
## Start Here: Your Complete Setup Guide

*Created by Flo Masta Jay (James Kelly, PMP®) | Aquarius Aeon Medias LLC*
*Part of the Worthy to Wealthy (W2W) Project — Philanthropic AI Workflows*

---

## Welcome

This is a free, open-access version of the TSA Job Hunt Stack — a professional-grade
AI-powered job search system designed to work with the **free Claude.ai chat** (no paid
subscription required).

Whether you have an hour at the library or a quiet evening at home, this stack gives you
the same structured approach that professionals use to run an organized, values-aligned
job search — powered entirely by free tools.

> **This stack was created by a Theory Z-motivated professional who believes that access
> to professional tools should not be gated by income. You deserve a fighting chance.
> This is yours — use it freely.**

---

## What You Need (All Free)

| Tool | Purpose | Cost |
|------|---------|------|
| Claude.ai (free account) | Your AI assistant | Free |
| Simplify Jobs | ATS keyword check + job autofill | Free |
| Teal HQ | Resume builder + job match scoring | Free tier |
| Jobscan | ATS + SEO score checker | Free scans/month |
| Job_Hunt_Template.xlsx | Your job tracking spreadsheet | Free (included) |
| Google Sheets or Excel | Open the tracker | Free (Google) |

---

## How This Works

Unlike the Cowork version (which needs a paid Claude plan), this free version gives you
**ready-to-paste AI prompts**. Each prompt IS the assistant — you paste it into Claude.ai
free, then follow the conversation.

**The 4 Prompts:**
| File | What It Does |
|------|-------------|
| `PROMPTS/PROMPT_01_JOB_SEARCH.md` | Searches for jobs matching your profile |
| `PROMPTS/PROMPT_02_LEAD_TRIAGE.md` | Evaluates and prioritizes your leads |
| `PROMPTS/PROMPT_03_COVER_LETTER.md` | Writes a tailored cover letter |
| `PROMPTS/PROMPT_04_WEEKLY_FLOW.md` | Plans your week and tracks progress |

---

## Before Your First Session — 15-Minute Setup

### Step 1: Fill Out Your Profile (5 minutes)
Open `01_MY_PROFILE_TEMPLATE.md` and fill in your info. You'll paste this into Claude
alongside each prompt so it knows who you are.

### Step 2: Set Up Your Keywords (5 minutes)
Open `02_ATS_KEYWORDS_TEMPLATE.md` and list the skills and keywords that appear in your
target job descriptions. You'll use this when running the ATS check.

### Step 3: Open Your Tracker (2 minutes)
Open `TRACKER/Job_Hunt_Template.xlsx` in Excel or upload it to Google Sheets. This is
where you'll log every lead. Keep it open whenever you're job hunting.

### Step 4: Create a Free Claude Account (2 minutes — skip if you have one)
Go to claude.ai → Sign up for free → You're ready.

---

## How to Use the Prompts

### The Golden Rule
**Always paste your profile alongside the prompt.** Copy the content of
`01_MY_PROFILE_TEMPLATE.md` and paste it right after the prompt text when starting a
new Claude conversation. This tells Claude who you are before it does any work.

### Starting a Session
1. Open claude.ai in your browser
2. Start a new conversation
3. Open the prompt file for the task you want to do
4. Copy the full prompt text
5. Paste it into Claude
6. When Claude asks for your profile info, paste `01_MY_PROFILE_TEMPLATE.md`
7. Follow Claude's guidance from there

### One-Hour Library Session Plan
If you only have 60 minutes, use this order:
- **0:00–0:05** — Open Claude.ai, paste Prompt 01 (Job Search), paste your profile
- **0:05–0:25** — Claude finds Top 10 leads → You pick your Top 3
- **0:25–0:40** — Paste Prompt 02 (Lead Triage) → Claude evaluates your Top 3
- **0:40–0:58** — Paste Prompt 03 (Cover Letter) → Claude writes one cover letter
- **0:58–1:00** — Log everything in your Job_Hunt_Template.xlsx before you close

---

## The Free Tool Workflow (ATS Optimization)

Run this when you have a resume ready to send:

1. **Teal HQ** (teal.io) → Upload your resume → Run Job Match against the job description
2. **Simplify** (simplify.jobs) → Install the Chrome extension → Run resume check
3. **Jobscan** (jobscan.co) → Paste your resume + JD → Get your ATS score
4. **Target: 70%+ match.** Update Core Competencies and Summary only — never edit achievement bullets.
5. Re-run through Teal to confirm improvement

See `FREE_TOOLS_GUIDE.md` for detailed instructions on each tool.

---

## Updating Your Tracker

After every Claude session, manually log your results in `Job_Hunt_Template.xlsx`:

**Job Leads tab columns to fill:**
- Status (Interested / Applied / Interview / Accepted / Rejected)
- Company Name, Job Title, Link
- Salary Range, Remote status
- Notes (which resume + cover letter you used)

The tracker is your memory across sessions. Treat it like gold.

---

## Getting More From This Stack

If you find this helpful and later get access to a paid Claude plan, the
**TSA Job Hunt Stack — Cowork Edition** gives you all of this plus:
- Automatic file reading (no copy-paste needed)
- Scheduled weekly job searches
- Automatic tracker updates
- Full workflow coordination across sessions

Both editions are available at: https://github.com/Zextalix

---

## Attribution

**Stack created by:** James Kelly, PMP® | Flo Masta Jay | Aquarius Aeon Medias LLC
*"From worthy to wealthy — one flow at a time."*

The ETF™ and AIRI™ frameworks used in the original private version of this stack are
available free to read at: https://snowfieldrhapsody.wordpress.com
