# Free Tools Guide — ATS Optimization & Job Search Resources

*All tools below are free or have a meaningful free tier. No paid subscriptions required.*

---

## The ATS Optimization Sequence

Run your resume through these tools IN ORDER before every application:

---

### Tool 1 — Teal HQ (teal.io)
**What it does:** Resume builder + Job Match scoring
**Why use it first:** Gives you a baseline score and identifies format issues

**How to use it:**
1. Go to teal.io → Create a free account
2. Upload your resume (PDF or Word)
3. Click "Job Match" → Paste the job description
4. Review your match score and the keyword gaps it identifies
5. Note the missing keywords — you'll add these to Core Competencies and Summary only
6. **Do NOT change achievement bullet points** — only adjust Core Competencies and Summary

**What to aim for:** 70%+ match. If below 60%, review the keyword gaps carefully.

---

### Tool 2 — Simplify (simplify.jobs)
**What it does:** ATS checker + job application autofill + job tracking
**Why use it:** Most thorough free ATS check; also auto-fills repetitive application forms

**How to use it:**
1. Go to simplify.jobs → Create a free account
2. Install the Simplify Chrome extension (highly recommended)
3. Upload your resume → Run the ATS check against the job description
4. Compare results with Teal — different algorithms catch different gaps
5. The Chrome extension autofills job application questions as you apply (saves huge time)
6. **Bonus:** Use Simplify's job tracking alongside your Job_Hunt_Template.xlsx

**What to aim for:** 70%+ keyword match. Minimum 60%.

---

### Tool 3 — Jobscan (jobscan.co)
**What it does:** Combined ATS + SEO score check
**Why use it:** Cross-validates Teal and Simplify results; different scoring algorithm

**How to use it:**
1. Go to jobscan.co → Free account (limited scans per month)
2. Paste your resume text + paste the job description
3. Run the scan → Review the match rate and hard skills gap
4. Compare with your Teal and Simplify results
5. Keep the resume version that scores best across all three tools

**Free tier:** ~5 scans per month. Prioritize your top 3 applications.

---

### After Running All Three Tools

1. Make your keyword adjustments (Core Competencies + Summary only)
2. Re-run Teal to confirm improvement
3. If you hit 70%+, the resume is ready to send
4. Log your final score in `02_ATS_KEYWORDS_TEMPLATE.md` → Role-Specific Keyword Log

---

## Job Board Resources (Free)

| Board | Best For |
|-------|----------|
| LinkedIn Jobs (linkedin.com/jobs) | Professional roles, networking connections |
| Indeed (indeed.com) | Volume search, salary data |
| Glassdoor (glassdoor.com) | Culture reviews + salary benchmarks |
| Remote OK (remoteok.com) | Remote-first tech + professional roles |
| We Work Remotely (weworkremotely.com) | Remote roles across industries |
| Idealist (idealist.org) | Nonprofit + mission-driven roles |
| AngelList/Wellfound (wellfound.com) | Startup roles |
| USAJobs (usajobs.gov) | US federal government roles |
| Handshake (joinhandshake.com) | Early career + recent grad roles |

---

## Resume Building (Free)

| Tool | Use For |
|------|---------|
| Teal HQ Resume Builder | ATS-friendly templates, LinkedIn import |
| Google Docs (Resume Templates) | Simple, clean formatting |
| Canva (canva.com) | Visual/creative roles (use with caution for ATS) |
| Resume.io | Quick professional templates |

**ATS Warning:** Avoid heavily designed templates (columns, tables, graphics) for ATS submissions.
Use clean, single-column formatting for all online applications.

---

## Interview Prep (Free)

| Tool | Use For |
|------|---------|
| Glassdoor Interview Questions | Company-specific interview Q&As |
| LinkedIn Interview Prep | AI mock interviews (free tier available) |
| Big Interview (biginterview.com) | Mock interview practice |
| Claude.ai | "Help me prepare for a [role] interview at [company]" — paste JD and profile |

---

## Networking (Free)

- **LinkedIn** — Connect with hiring managers and recruiters; comment meaningfully on posts
- **Meetup (meetup.com)** — Find local professional events in your field
- **Eventbrite** — Search for free virtual career events and workshops
- **Local library** — Job search workshops, resume review sessions, free printing

---

## A Note on Free vs. Paid

These free tools are genuinely powerful. Many working professionals use only free tools
throughout their entire job search. The goal of this stack is to show you that a
structured, professional-grade job search is 100% achievable without spending money.

If you later gain access to Claude Pro or Max and the Cowork edition of this stack,
the workflow simply becomes more automated — the underlying strategy is the same.

---

*Part of the TSA Job Hunt Stack — Free Edition*
*Created by Flo Masta Jay (James Kelly, PMP®) | Aquarius Aeon Medias LLC*
*W2W Project — From Worthy to Wealthy, one flow at a time.*
